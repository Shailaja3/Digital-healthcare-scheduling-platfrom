<?php
require_once '../inc/connect.php'; //my database connection, which also holds the functions file
if(!$doctor->is_loggedin())
{
$doctor->redirect('index.php');
}
// Getting the doctor id
$dct_id = $_SESSION['appointment'];

//If need, further actions can be done using this query
$stmt = $DB_con->prepare("SELECT * FROM doctor WHERE dct_id=:doctorId");
$stmt->execute(array(":dct_id"=>$dct_id));
$userRow=$stmt->fetch(PDO::FETCH_ASSOC);

//this part is for viewing the appointments
$aptid=$_GET['appId'];
$stmt2=$DB_con->prepare("SELECT COUNT(dct_id) as aptid FROM appointment WHERE dct_id=:aptid");
$stmt2->execute(array(":aptid"=>$aptid));
$aptRow=$stmt2->fetch(PDO::FETCH_ASSOC);
$newApt=$aptRow['aptid'];

if($newApt>0)
{ ?>

<div class="alert alert-info">You have <?php print ($newApt) ?> New Appointment! <br>
<button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#vwApt">View Appointment</button>
</div>

<?php }
else{ ?>

<div class="alert alert-warning">You have <?php print($newApt); ?> appointments!!</div>

<?php
}

?>